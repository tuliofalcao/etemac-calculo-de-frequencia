import flet as ft


def cabecalho():

        return ft.Column(
            ft.Container(
                ft.Column(
                    [
                        ft.Image(
                            src="ete.png",
                            width=200,
                            height=200
                        ),
                        ft.Text("Cálculo de Frequência Escolar", 
                        size=20, 
                        weight=ft.FontWeight.NORMAL,
                        text_align=ft.MainAxisAlignment.CENTER,
                        color=ft.Colors.GREY_600,
                        margin=ft.Margin.only(bottom=20)
                        ),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    tight=True,
                    spacing=5
                ),
                alignment=ft.Alignment.CENTER,
                bgcolor=ft.Colors.GREY_50,
                border_radius=ft.BorderRadius.all(10)
                )
            )