import flet as ft


# ----------------------------- MESES -------------------------------


# ------ TOTAL --------

resultado_final_total = ft.Text("0.0%", size=50, weight="bold")

todos_resultados = []

def calcular_media_geral(todos_resultados):
    # Lista com todos os seus objetos de texto de resultado
    
    soma = 0.0
    contagem = 0
    
    for res in todos_resultados:
        if res: # Se não estiver vazio
            try:
                # Remove o % e converte para float
                valor_limpo = float(res.replace("%", ""))
                soma += valor_limpo
                contagem += 1
            except ValueError:
                continue
                
    if contagem > 0:
        media = soma / contagem
        resultado_final_total.value = f"{media:.1f}%"
    else:
        resultado_final_total.value = "0.0%"


#--- FEVEREIRO ---

fevereiro = ft.TextField(
    width=250,
    label="Faltas de Fevereiro",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_fev(e)
    )    

diasLetivos_fevereiro = 16  # Número de dias letivos em fevereiro
resultado_fevereiro = ft.Text(size=30) # Retorno do resultado da frequência

# Cálculo da frequência de fevereiro
def calcular_fev(e):

    if fevereiro.value is None or fevereiro.value == "":
        resultado_fevereiro.value = ""
        e.page.update()
        return

    fevereiro_freq = 100 - ((int(fevereiro.value)* 100) / (diasLetivos_fevereiro * 9))
    resultado_fevereiro.value = f"{fevereiro_freq:.1f}%"
    valor = resultado_fevereiro.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return


#--- MARÇO ---/

marco = ft.TextField(
    width=250,
    label="Faltas de Março",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_mar(e)
    )

diasLetivos_marco = 21 # Número de dias letivos em março
resultado_marco = ft.Text(size=30) # Retorno do resultado da frequência
    
# Cálculo da frequência de março
def calcular_mar(e):

    if marco.value is None or marco.value == "":
        resultado_marco.value = ""
        e.page.update()
        return

    marco_freq = 100 - ((int(marco.value)* 100) / (diasLetivos_marco * 9))
    resultado_marco.value = f"{marco_freq:.1f}%"
    valor = resultado_marco.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)    
    e.page.update()
    return


#--- ABRIL ---/

abril = ft.TextField(
    width=250,
    label="Faltas de Abril",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_abr(e)
    )

diasLetivos_abril = 18 # Número de dias letivos em abril
resultado_abril = ft.Text(size=30) # Retorno do resultado da frequência

# Cálculo da frequência de abril
def calcular_abr(e):

    if abril.value is None or abril.value == "":
        resultado_abril.value = ""
        e.page.update()
        return

    abril_freq = 100 - ((int(abril.value)* 100) / (diasLetivos_abril * 9))
    resultado_abril.value = f"{abril_freq:.1f}%"
    valor = resultado_abril.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return


#--- MAIO ---/

maio = ft.TextField(
    width=250,
    label="Faltas de Maio",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_mai(e)
    )

diasLetivos_maio = 19 # Número de dias letivos em maio
resultado_maio = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de maio
def calcular_mai(e):

    if maio.value is None or maio.value == "":
        resultado_maio.value = ""
        e.page.update()
        return

    maio_freq = 100 - ((int(maio.value)* 100) / (diasLetivos_maio * 9))
    resultado_maio.value = f"{maio_freq:.1f}%"
    valor = resultado_maio.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return


#--- JUNHO ---/

junho = ft.TextField(
    width=250,
    label="Faltas de Junho",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_jun(e)
    )

diasLetivos_junho = 20 # Número de dias letivos em junho
resultado_junho = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de junho
def calcular_jun(e):

    if junho.value is None or junho.value == "":
        resultado_junho.value = ""
        e.page.update()
        return

    junho_freq = 100 - ((int(junho.value)* 100) / (diasLetivos_junho * 9))
    resultado_junho.value = f"{junho_freq:.1f}%"
    valor = resultado_junho.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return


#--- JULHO ---/

julho = ft.TextField(
    width=250,
    label="Faltas de Julho",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_jul(e)
    )

diasLetivos_julho = 11 # Número de dias letivos em julho
resultado_julho = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de julho
def calcular_jul(e):

    if julho.value is None or julho.value == "":
        resultado_julho.value = ""
        e.page.update()
        return

    julho_freq = 100 - ((int(julho.value)* 100) / (diasLetivos_julho * 9))
    resultado_julho.value = f"{julho_freq:.1f}%"
    valor = resultado_julho.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return


#--- AGOSTO ---/

agosto = ft.TextField(
    width=250,
    label="Faltas de Agosto",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_ago(e)
    )

diasLetivos_agosto = 21 # Número de dias letivos em agosto
resultado_agosto = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de agosto
def calcular_ago(e):

    if agosto.value is None or agosto.value == "":
        resultado_agosto.value = ""
        e.page.update()
        return

    agosto_freq = 100 - ((int(agosto.value)* 100) / (diasLetivos_agosto * 9))
    resultado_agosto.value = f"{agosto_freq:.1f}%"
    valor = resultado_agosto.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return


#--- SETEMBRO ---/

setembro = ft.TextField(
    width=250,
    label="Faltas de Setembro",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_set(e)
    )

diasLetivos_setembro = 20 # Número de dias letivos em setembro
resultado_setembro = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de setembro
def calcular_set(e):

    if setembro.value is None or setembro.value == "":
        resultado_setembro.value = ""
        e.page.update()
        return

    setembro_freq = 100 - ((int(setembro.value)* 100) / (diasLetivos_setembro * 9))
    resultado_setembro.value = f"{setembro_freq:.1f}%"
    valor = resultado_setembro.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return


#--- OUTUBRO ---/

outubro = ft.TextField(
    width=250,
    label="Faltas de Outubro",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_out(e)
    )

diasLetivos_outubro = 19 # Número de dias letivos em outubro
resultado_outubro = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de outubro
def calcular_out(e):

    if outubro.value is None or outubro.value == "":
        resultado_outubro.value = ""
        e.page.update()
        return

    outubro_freq = 100 - ((int(outubro.value)* 100) / (diasLetivos_outubro * 9))
    resultado_outubro.value = f"{outubro_freq:.1f}%"
    valor = resultado_outubro.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return  


#--- NOVEMBRO ---/

novembro = ft.TextField(
    width=250,
    label="Faltas de Novembro",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_nov(e)
    )   

diasLetivos_novembro = 19 # Número de dias letivos em novembro
resultado_novembro = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de novembro
def calcular_nov(e):    

    if novembro.value is None or novembro.value == "":
        resultado_novembro.value = ""
        e.page.update()
        return

    novembro_freq = 100 - ((int(novembro.value)* 100) / (diasLetivos_novembro * 9))
    resultado_novembro.value = f"{novembro_freq:.1f}%"
    valor = resultado_novembro.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return  


#--- DEZEMBRO ---/

dezembro = ft.TextField(
    width=250,
    label="Faltas de Dezembro",
    hint_text="Insira a quantidade de faltas e tecle ENTER",
    text_align=ft.TextAlign.CENTER,
    border_radius=ft.BorderRadius.all(10),
    on_submit=lambda e: calcular_dez(e)
    )               

diasLetivos_dezembro = 17 # Número de dias letivos em dezembro
resultado_dezembro = ft.Text(size=30) # Retorno do resultado da frequência
# Cálculo da frequência de dezembro
def calcular_dez(e):

    if dezembro.value is None or dezembro.value == "":
        resultado_dezembro.value = ""
        e.page.update()
        return

    dezembro_freq = 100 - ((int(dezembro.value)* 100) / (diasLetivos_dezembro * 9))
    resultado_dezembro.value = f"{dezembro_freq:.1f}%"
    valor = resultado_dezembro.value
    todos_resultados.append(valor)
    calcular_media_geral(todos_resultados)
    e.page.update()
    return  