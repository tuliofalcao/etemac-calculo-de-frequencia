import flet as ft
from components.meses import fevereiro, resultado_fevereiro, calcular_fev
from components.meses import marco, resultado_marco, calcular_mar  
from components.cabecalho import cabecalho
from components.calculo import calculo


def main(page: ft.Page):
    
    page.title = "ETEMAC - Cálculo de Frequência"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.scroll = ft.ScrollMode.ALWAYS
    page.bgcolor = ft.Colors.GREY_50

        
    page.add(
        cabecalho(),
        calculo()
        )

ft.run(main)
